import { useLocalStorage } from './useLocalStorage'
import { COLUMNS, LOCALSTORAGE_KEY } from '../constants'
import { reorderSkillsInColumn } from '../utils/helpers'

/**
 * Beceri (skill) CRUD ve sütun taşıma işlemleri için custom hook.
 */
export function useSkills() {
  const [skills, setSkills] = useLocalStorage(LOCALSTORAGE_KEY, [])

  // Yeni beceri ekle
  const addSkill = (skillData) => {
    const newSkill = {
      id: crypto.randomUUID(),
      title: skillData.title.trim(),
      description: skillData.description?.trim() || '',
      category: skillData.category || 'other',
      difficulty: skillData.difficulty || 'medium',
      priority: skillData.priority || 'normal',
      deadline: skillData.deadline || '',
      status: COLUMNS.TODO,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setSkills((prev) => [newSkill, ...prev])
    return newSkill
  }

  // Beceri güncelle
  const updateSkill = (id, updates) => {
    setSkills((prev) =>
      prev.map((skill) =>
        skill.id === id
          ? { ...skill, ...updates, updatedAt: new Date().toISOString() }
          : skill
      )
    )
  }

  // Beceri sil
  const deleteSkill = (id) => {
    setSkills((prev) => prev.filter((skill) => skill.id !== id))
  }

  // Beceriyi başka sütuna taşı
  const moveSkill = (id, newStatus) => {
    setSkills((prev) =>
      prev.map((skill) =>
        skill.id === id
          ? { ...skill, status: newStatus, updatedAt: new Date().toISOString() }
          : skill
      )
    )
  }

  const reorderSkills = (activeId, overId) => {
    setSkills((prev) => reorderSkillsInColumn(prev, activeId, overId))
  }

  // İstatistikler
  const stats = {
    total: skills.length,
    todo: skills.filter((s) => s.status === COLUMNS.TODO).length,
    inProgress: skills.filter((s) => s.status === COLUMNS.IN_PROGRESS).length,
    done: skills.filter((s) => s.status === COLUMNS.DONE).length,
    completionRate:
      skills.length > 0
        ? Math.round(
            (skills.filter((s) => s.status === COLUMNS.DONE).length /
              skills.length) *
              100
          )
        : 0,
  }

  return {
    skills,
    addSkill,
    updateSkill,
    deleteSkill,
    moveSkill,
    reorderSkills,
    stats,
  }
}
