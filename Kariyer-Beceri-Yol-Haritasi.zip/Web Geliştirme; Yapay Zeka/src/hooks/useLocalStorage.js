import { useState, useEffect } from 'react'

/**
 * localStorage ile senkronize tutulan state hook'u.
 * @param {string} key - localStorage anahtarı
 * @param {*} initialValue - Başlangıç değeri
 */
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch (error) {
      console.warn(`localStorage okuma hatası [${key}]:`, error)
      return initialValue
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.warn(`localStorage yazma hatası [${key}]:`, error)
    }
  }, [key, value])

  return [value, setValue]
}
