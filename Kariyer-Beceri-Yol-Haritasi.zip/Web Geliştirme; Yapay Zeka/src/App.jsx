import { useEffect, useState, useCallback } from 'react'
import { useSkills } from './hooks/useSkills'
import StatsHeader from './components/layout/StatsHeader'
import KanbanBoard from './components/kanban/KanbanBoard'
import AddSkillModal from './components/skill/AddSkillModal'
import EditSkillModal from './components/skill/EditSkillModal'
import SearchBar from './components/ui/SearchBar'
import StatsPage from './components/stats/StatsPage'

const OPENAI_MODEL = import.meta.env.VITE_OPENAI_MODEL || 'openai/gpt-4o-mini'

const cleanAiText = (text) => {
  if (!text) return []

  return text
    .split(/\n|•|-/)
    .map((line) => line.replace(/^[\s\d.)]*|[\s\d.)]*$/g, '').trim())
    .filter(Boolean)
    .filter((line) => line.length > 10)
    .slice(0, 3)
}

/**
 * Uygulama kök bileşeni.
 * State yönetimi useSkills hook'unda, görünüm bu bileşende birleştirilir.
 */
export default function App() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [editingSkill, setEditingSkill] = useState(null)   // düzenlenen kart
  const [showStats, setShowStats] = useState(false)        // istatistik sayfası
  const [search, setSearch] = useState('')                 // arama metni
  const [activeCategory, setActiveCategory] = useState('') // kategori filtresi
  const [aiSuggestions, setAiSuggestions] = useState([])
  const [isAiLoading, setIsAiLoading] = useState(false)
  const [aiError, setAiError] = useState('')

  const { skills, addSkill, updateSkill, deleteSkill, moveSkill, reorderSkills, stats } = useSkills()

  const getSmartSuggestions = useCallback(() => {
    if (skills.length === 0) {
      return [
        'İlk hedefini ekleyerek kariyer yol haritanı başlat.',
        'Önceliklerini belirleyip kısa vadeli hedefler oluştur.',
        'Becerilerini kategorilere göre düzenle ve ilerlemeyi takip et.',
      ]
    }

    const todo = skills.filter((skill) => skill.status === 'todo').length
    const done = skills.filter((skill) => skill.status === 'done').length
    const highPriority = skills.filter((skill) => skill.priority === 'high' || skill.priority === 'critical').length

    const suggestions = []

    if (todo > 0) {
      suggestions.push(`Bugün için ${todo} başlatılacak hedefin var; en kritik olanı ilk sıraya al.`)
    }

    if (done === 0) {
      suggestions.push('Henüz tamamlanan hedef yok. İlk başarı adımını küçük ve ölçülebilir bir hedefle başlat.')
    }

    if (highPriority > 0) {
      suggestions.push(`${highPriority} yüksek öncelikli hedefin var. Bu görevleri önce tamamlamaya odaklan.`)
    }

    suggestions.push('İlerlemeyi düzenli takip etmek için haftalık hedefleri ve son tarihleri güncel tut.')
    return suggestions.slice(0, 3)
  }, [skills])

  const refreshAiSuggestions = useCallback(async () => {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY

    if (!apiKey) {
      setAiSuggestions(getSmartSuggestions())
      setAiError('')
      return
    }

    setIsAiLoading(true)
    setAiError('')

    try {
      const skillSummary = skills.length === 0
        ? 'Henüz hedef yok; kullanıcının kariyer yol haritasını başlatması gerekiyor.'
        : skills.map((s) => `${s.title} (${s.category}, ${s.status}, ${s.priority || 'normal'})`).join('; ')

      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': window.location.origin,
          'X-Title': 'Kariyer Yol Haritası',
        },
        body: JSON.stringify({
          model: OPENAI_MODEL,
          messages: [
            {
              role: 'system',
              content: 'Sen deneyimli kariyer koçu ve öğrenme planlayıcısın. Kullanıcıya en fazla 3 maddelik net öneriler ver. Her cümle kısa, pratik ve kişisel gelişim odaklı olsun.',
            },
            {
              role: 'user',
              content: `Kullanıcının mevcut hedefleri ve ilerlemesi şunlar: ${skillSummary}. Bu veriye göre 3 tane kısa, uygulamaya dönük kariyer gelişim önerisi ver.`,
            },
          ],
          temperature: 0.7,
        }),
      })

      if (!response.ok) {
        throw new Error('AI servisi yanıt vermedi.')
      }

      const data = await response.json()
      const content = data?.choices?.[0]?.message?.content || ''
      const parsed = cleanAiText(content)

      if (parsed.length > 0) {
        setAiSuggestions(parsed)
      } else {
        setAiSuggestions(getSmartSuggestions())
      }
    } catch {
      setAiSuggestions(getSmartSuggestions())
      setAiError('AI servisi şu anda cevap vermedi; yerel öneriler gösteriliyor.')
    } finally {
      setIsAiLoading(false)
    }
  }, [getSmartSuggestions, skills])

  useEffect(() => {
    setAiSuggestions(getSmartSuggestions())
  }, [skills])

  // Arama + kategori filtresi uygulanmış beceriler
  const filteredSkills = skills.filter((s) => {
    const matchSearch = search === '' ||
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.description?.toLowerCase().includes(search.toLowerCase())
    const matchCategory = activeCategory === '' || s.category === activeCategory
    return matchSearch && matchCategory
  })

  const isFiltering = search !== '' || activeCategory !== ''

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Arkaplan dekoratif gradyanlar */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-slate-900/50 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* İstatistik başlığı + ekleme butonu */}
        <StatsHeader
          stats={stats}
          onAddClick={() => setIsAddModalOpen(true)}
          onStatsClick={() => setShowStats(true)}
        />

        {/* Arama & Filtre */}
        <SearchBar
          search={search}
          onSearchChange={setSearch}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />

        <div className="glass-card p-5 mb-6 animate-fade-in">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Yapay Zeka Önerileri</h2>
                <p className="text-xs text-slate-500">
                  {import.meta.env.VITE_OPENAI_API_KEY ? 'Canlı AI önerisi aktif' : 'Yerel öneri modu aktif'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={refreshAiSuggestions}
              disabled={isAiLoading}
              className="btn-secondary text-xs px-3 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAiLoading ? 'Düşünüyor...' : 'AI Yenile'}
            </button>
          </div>

          {aiError && (
            <p className="mb-3 text-xs text-amber-300">{aiError}</p>
          )}

          <ul className="space-y-2 text-sm text-slate-300">
            {(aiSuggestions.length > 0 ? aiSuggestions : getSmartSuggestions()).map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="mt-1.5 w-2 h-2 rounded-full bg-indigo-400 flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Kanban panosu */}
        <section aria-label="Kariyer Kanban Panosu">
          {/* Filtre sonucu boş */}
          {isFiltering && filteredSkills.length === 0 ? (
            <div className="glass-card p-12 text-center animate-fade-in">
              <div className="text-4xl mb-3">🔍</div>
              <h2 className="text-lg font-bold text-white mb-2">Sonuç bulunamadı</h2>
              <p className="text-slate-400 text-sm">
                "{search || activeCategory}" için eşleşen beceri yok.
              </p>
              <button
                onClick={() => { setSearch(''); setActiveCategory('') }}
                className="btn-secondary mt-4"
              >
                Filtreyi Temizle
              </button>
            </div>
          ) : skills.length === 0 ? (
            /* Hiç beceri yoksa boş durum */
            <div className="glass-card p-12 text-center animate-fade-in">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-500/20 to-violet-500/20 rounded-3xl flex items-center justify-center mx-auto mb-5">
                <svg className="w-10 h-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-white mb-2">
                Henüz bir hedef yok!
              </h2>
              <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
                İlk kariyer hedefini veya öğrenmek istediğin beceriyi ekleyerek yolculuğuna başla.
              </p>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="btn-primary"
                id="empty-state-add-btn"
              >
                İlk Hedefini Ekle 🚀
              </button>
            </div>
          ) : (
            <KanbanBoard
              skills={filteredSkills}
              onDelete={deleteSkill}
              onMove={moveSkill}
              onReorder={reorderSkills}
              onEdit={(skill) => setEditingSkill(skill)}
            />
          )}
        </section>

        {/* Footer */}
        <footer className="mt-12 text-center text-slate-700 text-xs">
          <p>Kariyer & Beceri Yol Haritası • Veriler tarayıcı LocalStorage'a kaydedilir</p>
        </footer>
      </div>

      {/* Beceri ekleme modalı */}
      <AddSkillModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={addSkill}
      />

      {/* Beceri düzenleme modalı */}
      <EditSkillModal
        isOpen={editingSkill !== null}
        onClose={() => setEditingSkill(null)}
        onSave={updateSkill}
        skill={editingSkill}
      />

      {/* İstatistik sayfası (full-screen overlay) */}
      {showStats && (
        <StatsPage
          skills={skills}
          onClose={() => setShowStats(false)}
        />
      )}
    </div>
  )
}
