import { describe, expect, it } from 'vitest'
import { reorderSkillsInColumn } from './helpers'

const skills = [
  { id: 'todo-1', status: 'todo' },
  { id: 'progress-1', status: 'in-progress' },
  { id: 'todo-2', status: 'todo' },
  { id: 'done-1', status: 'done' },
]

describe('reorderSkillsInColumn', () => {
  it('reorders cards within their column and preserves other columns', () => {
    const reordered = reorderSkillsInColumn(skills, 'todo-1', 'todo-2')

    expect(reordered.map((skill) => skill.id)).toEqual([
      'todo-2',
      'progress-1',
      'todo-1',
      'done-1',
    ])
    expect(reordered[1]).toBe(skills[1])
    expect(reordered[3]).toBe(skills[3])
  })

  it('returns the original list when the drop target is not in the same column', () => {
    expect(reorderSkillsInColumn(skills, 'todo-1', 'progress-1')).toBe(skills)
    expect(reorderSkillsInColumn(skills, 'todo-1', 'missing')).toBe(skills)
  })

  it('returns the original list when the card is dropped onto itself', () => {
    expect(reorderSkillsInColumn(skills, 'todo-1', 'todo-1')).toBe(skills)
  })
})