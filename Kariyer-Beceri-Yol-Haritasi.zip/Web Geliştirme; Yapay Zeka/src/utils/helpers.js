import { CATEGORIES, DIFFICULTY_LEVELS, PRIORITY_LEVELS } from '../constants'

/**
 * Kategori rengini ve ikonunu döndürür.
 */
export function getCategoryMeta(categoryValue) {
  return (
    CATEGORIES.find((c) => c.value === categoryValue) ||
    CATEGORIES[CATEGORIES.length - 1]
  )
}

/**
 * Zorluk seviyesi rengini ve etiketini döndürür.
 */
export function getDifficultyMeta(difficultyValue) {
  return (
    DIFFICULTY_LEVELS.find((d) => d.value === difficultyValue) ||
    DIFFICULTY_LEVELS[1]
  )
}

export function getPriorityMeta(priorityValue) {
  return PRIORITY_LEVELS.find((p) => p.value === priorityValue) || PRIORITY_LEVELS[1]
}

/** Deadline durumunu hesaplar */
export function getDeadlineStatus(deadline) {
  if (!deadline) return null
  const now = new Date()
  const due = new Date(deadline)
  const diffDays = Math.ceil((due - now) / (1000 * 60 * 60 * 24))
  if (diffDays < 0) return { label: `${Math.abs(diffDays)} gün geçti`, color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30', urgent: true }
  if (diffDays === 0) return { label: 'Bugün son gün!', color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/30', urgent: true }
  if (diffDays <= 3) return { label: `${diffDays} gün kaldı`, color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30', urgent: true }
  return { label: `${diffDays} gün kaldı`, color: 'text-slate-400', bg: 'bg-slate-500/10 border-slate-500/30', urgent: false }
}

/**
 * Tarihi Türkçe formatlar.
 */
export function formatDate(isoString) {
  if (!isoString) return ''
  return new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(new Date(isoString))
}

export function reorderSkillsInColumn(skills, activeId, overId) {
  if (activeId === overId) return skills

  const activeSkill = skills.find((skill) => skill.id === activeId)
  const columnSkills = skills.filter((skill) => skill.status === activeSkill?.status)
  const oldIndex = columnSkills.findIndex((skill) => skill.id === activeId)
  const newIndex = columnSkills.findIndex((skill) => skill.id === overId)

  if (oldIndex < 0 || newIndex < 0) return skills

  const reorderedColumn = [...columnSkills]
  const [movedSkill] = reorderedColumn.splice(oldIndex, 1)
  reorderedColumn.splice(newIndex, 0, movedSkill)

  let columnIndex = 0
  return skills.map((skill) =>
    skill.status === activeSkill.status ? reorderedColumn[columnIndex++] : skill
  )
}
