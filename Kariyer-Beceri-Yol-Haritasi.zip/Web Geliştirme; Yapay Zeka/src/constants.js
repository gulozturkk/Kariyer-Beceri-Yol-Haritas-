// Kanban sütun sabitleri
export const COLUMNS = {
  TODO: 'todo',
  IN_PROGRESS: 'in-progress',
  DONE: 'done',
}

export const COLUMN_LABELS = {
  [COLUMNS.TODO]: 'Başlanacak',
  [COLUMNS.IN_PROGRESS]: 'Devam Ediyor',
  [COLUMNS.DONE]: 'Tamamlandı',
}

export const COLUMN_COLORS = {
  [COLUMNS.TODO]: {
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/30',
    badge: 'bg-indigo-500/20 text-indigo-300',
    dot: 'bg-indigo-400',
    header: 'text-indigo-300',
    count: 'bg-indigo-500/20 text-indigo-300',
    glow: 'shadow-indigo-500/10',
  },
  [COLUMNS.IN_PROGRESS]: {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    badge: 'bg-amber-500/20 text-amber-300',
    dot: 'bg-amber-400',
    header: 'text-amber-300',
    count: 'bg-amber-500/20 text-amber-300',
    glow: 'shadow-amber-500/10',
  },
  [COLUMNS.DONE]: {
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    badge: 'bg-emerald-500/20 text-emerald-300',
    dot: 'bg-emerald-400',
    header: 'text-emerald-300',
    count: 'bg-emerald-500/20 text-emerald-300',
    glow: 'shadow-emerald-500/10',
  },
}

// Beceri zorluk seviyeleri
export const DIFFICULTY_LEVELS = [
  { value: 'easy', label: 'Kolay', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
  { value: 'medium', label: 'Orta', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  { value: 'hard', label: 'Zor', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
]

// Kategoriler
export const CATEGORIES = [
  { value: 'frontend', label: 'Frontend', icon: '🎨', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  { value: 'backend', label: 'Backend', icon: '⚙️', color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
  { value: 'devops', label: 'DevOps', icon: '🚀', color: 'bg-orange-500/20 text-orange-300 border-orange-500/30' },
  { value: 'mobile', label: 'Mobil', icon: '📱', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
  { value: 'data', label: 'Veri Bilimi', icon: '📊', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
  { value: 'ai', label: 'Yapay Zeka', icon: '🤖', color: 'bg-pink-500/20 text-pink-300 border-pink-500/30' },
  { value: 'softskills', label: 'Soft Skills', icon: '🤝', color: 'bg-teal-500/20 text-teal-300 border-teal-500/30' },
  { value: 'other', label: 'Diğer', icon: '📌', color: 'bg-gray-500/20 text-gray-300 border-gray-500/30' },
]

export const LOCALSTORAGE_KEY = 'kariyer_yol_haritasi_skills'

// Öncelik seviyeleri
export const PRIORITY_LEVELS = [
  { value: 'low',      label: 'Düşük',   icon: '🟢', color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
  { value: 'normal',   label: 'Normal',  icon: '🔵', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  { value: 'high',     label: 'Yüksek',  icon: '🟡', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  { value: 'critical', label: 'Kritik',  icon: '🔴', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
]
