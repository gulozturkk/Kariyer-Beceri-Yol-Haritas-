import { useDroppable } from '@dnd-kit/core'
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable'
import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import SkillCard from '../skill/SkillCard'
import { COLUMN_COLORS, COLUMN_LABELS } from '../../constants'

/**
 * Sortable wrapper her bir SkillCard için.
 */
function SortableSkillCard({ skill, onDelete, onMove, onEdit }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: skill.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <div ref={setNodeRef} style={style}>
      <SkillCard
        skill={skill}
        onDelete={onDelete}
        onMove={onMove}
        onEdit={onEdit}
        isDragging={isDragging}
        dragHandleProps={{ ...attributes, ...listeners }}
      />
    </div>
  )
}

/**
 * Tek bir Kanban sütunu bileşeni.
 */
export default function KanbanColumn({ status, skills, onDelete, onMove, onEdit }) {
  const colors = COLUMN_COLORS[status]
  const label = COLUMN_LABELS[status]

  const { setNodeRef, isOver } = useDroppable({ id: status })

  const columnClass = [
    'kanban-column border',
    isOver ? colors.bg + ' ' + colors.border : 'border-transparent',
    'transition-all duration-200',
  ].join(' ')

  return (
    <div className="flex flex-col min-w-0">
      {/* Sütun başlığı */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2.5">
          <div className={`w-2.5 h-2.5 rounded-full ${colors.dot} shadow-sm`} />
          <h2 className={`font-bold text-sm uppercase tracking-wider ${colors.header}`}>
            {label}
          </h2>
        </div>
        <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${colors.count}`}>
          {skills.length}
        </span>
      </div>

      {/* Sürüklenebilir alan */}
      <SortableContext
        items={skills.map((s) => s.id)}
        strategy={verticalListSortingStrategy}
      >
        <div
          ref={setNodeRef}
          className={columnClass}
        >
          {skills.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                {status === 'todo' ? 'Yeni hedef ekle!' : 'Buraya taşı'}
              </p>
            </div>
          ) : (
            skills.map((skill) => (
              <SortableSkillCard
                key={skill.id}
                skill={skill}
                onDelete={onDelete}
                onMove={onMove}
                onEdit={onEdit}
              />
            ))
          )}
        </div>
      </SortableContext>
    </div>
  )
}
