import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners,
} from '@dnd-kit/core'
import { useState } from 'react'
import { COLUMNS } from '../../constants'
import KanbanColumn from './KanbanColumn'
import SkillCard from '../skill/SkillCard'

/**
 * Üç sütunlu Kanban panosu.
 * @dnd-kit ile sürükle-bırak desteği.
 */
export default function KanbanBoard({ skills, onDelete, onMove, onReorder, onEdit }) {
  const [activeSkill, setActiveSkill] = useState(null)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  )

  const getSkillsByStatus = (status) => skills.filter((s) => s.status === status)

  const handleDragStart = ({ active }) => {
    const skill = skills.find((s) => s.id === active.id)
    setActiveSkill(skill || null)
  }

  const handleDragEnd = ({ active, over }) => {
    setActiveSkill(null)
    if (!over) return

    const activeId = active.id
    const overId = over.id

    // over bir sütun id'si mi yoksa kart id'si mi?
    const isOverColumn = Object.values(COLUMNS).includes(overId)
    const overSkill = skills.find((s) => s.id === overId)
    const targetStatus = isOverColumn ? overId : overSkill?.status

    if (!targetStatus) return

    const draggedSkill = skills.find((s) => s.id === activeId)
    if (!draggedSkill) return

    if (draggedSkill.status !== targetStatus) {
      // Farklı sütuna taşı
      onMove(activeId, targetStatus)
    } else if (overSkill && activeId !== overId) {
      onReorder(activeId, overId)
    }
  }

  const handleDragCancel = () => setActiveSkill(null)

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.values(COLUMNS).map((status) => (
          <KanbanColumn
            key={status}
            status={status}
            skills={getSkillsByStatus(status)}
            onDelete={onDelete}
            onMove={onMove}
            onEdit={onEdit}
          />
        ))}
      </div>

      {/* Sürüklenen kartın overlay görseli */}
      <DragOverlay>
        {activeSkill ? (
          <div className="rotate-2 opacity-90 scale-105">
            <SkillCard skill={activeSkill} onDelete={() => {}} onMove={() => {}} isDragging />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  )
}
