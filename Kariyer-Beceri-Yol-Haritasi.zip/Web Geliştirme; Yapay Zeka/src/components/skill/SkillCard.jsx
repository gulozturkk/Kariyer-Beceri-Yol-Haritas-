import { getCategoryMeta, getDifficultyMeta, formatDate, getPriorityMeta, getDeadlineStatus } from '../../utils/helpers'
import { COLUMNS, COLUMN_LABELS } from '../../constants'

/**
 * Kanban sütunundaki tek bir beceri kartı.
 * Sürükle-bırak için data-id attribute kullanır.
 */
export default function SkillCard({
  skill,
  onDelete,
  onMove,
  onEdit,
  isDragging = false,
  dragHandleProps = {},
}) {
  const category = getCategoryMeta(skill.category)
  const difficulty = getDifficultyMeta(skill.difficulty)
  const priority = getPriorityMeta(skill.priority)
  const deadlineStatus = getDeadlineStatus(skill.deadline)

  // Hangi sütuna taşınabilir?
  const moveOptions = Object.values(COLUMNS).filter((col) => col !== skill.status)

  return (
    <div
      className={`skill-card animate-fade-in ${isDragging ? 'skill-card-dragging' : ''}`}
      data-skill-id={skill.id}
    >
      {/* Drag tutacağı + Başlık satırı */}
      <div className="flex items-start gap-2 mb-3">
        <div
          {...dragHandleProps}
          className="mt-0.5 text-slate-600 hover:text-slate-400 transition-colors cursor-grab active:cursor-grabbing flex-shrink-0"
          title="Taşı"
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z" />
          </svg>
        </div>

        <h3 className="flex-1 font-semibold text-slate-100 text-sm leading-snug line-clamp-2">
          {skill.title}
        </h3>

        {/* Düzenle butonu */}
        <button
          onClick={() => onEdit && onEdit(skill)}
          className="flex-shrink-0 p-1 text-slate-600 hover:text-indigo-400 transition-colors duration-200 rounded-lg hover:bg-indigo-400/10"
          title="Düzenle"
          aria-label={`${skill.title} düzenle`}
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
        </button>

        {/* Sil butonu */}
        <button
          onClick={() => onDelete(skill.id)}
          className="flex-shrink-0 p-1 text-slate-600 hover:text-rose-400 transition-colors duration-200 rounded-lg hover:bg-rose-400/10"
          title="Sil"
          aria-label={`${skill.title} sil`}
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>

      {/* Açıklama */}
      {skill.description && (
        <p className="text-xs text-slate-400 mb-3 line-clamp-2 leading-relaxed">
          {skill.description}
        </p>
      )}

      {/* Rozetler */}
      <div className="flex items-center gap-2 flex-wrap mb-3">
        {/* Kategori rozeti */}
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-medium border ${category.color}`}>
          <span>{category.icon}</span>
          {category.label}
        </span>

        {/* Zorluk rozeti */}
        <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-semibold border ${difficulty.color}`}>
          {difficulty.label}
        </span>

        {/* Öncelik rozeti */}
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-semibold border ${priority.color} ${skill.priority === 'critical' ? 'animate-pulse' : ''}`}>
          <span>{priority.icon}</span>
          {priority.label}
        </span>
      </div>

      {/* Deadline göstergesi */}
      {deadlineStatus && (
        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs mb-3 ${deadlineStatus.bg} ${deadlineStatus.color}`}>
          <span>{deadlineStatus.urgent ? '⚠️' : '📅'}</span>
          <span className="font-medium">{deadlineStatus.label}</span>
        </div>
      )}

      {/* Taşı butonları */}
      {moveOptions.length > 0 && (
        <div className="flex gap-1.5 flex-wrap">
          {moveOptions.map((col) => (
            <button
              key={col}
              onClick={() => onMove(skill.id, col)}
              className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 hover:border-white/20 text-slate-400 hover:text-slate-200 transition-all duration-200 flex items-center gap-1"
              title={`"${COLUMN_LABELS[col]}" sütununa taşı`}
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
              {COLUMN_LABELS[col]}
            </button>
          ))}
        </div>
      )}

      {/* Tarih */}
      <div className="mt-3 pt-3 border-t border-white/5">
        <span className="text-xs text-slate-600">{formatDate(skill.createdAt)}</span>
      </div>
    </div>
  )
}
