import { useState, useEffect } from 'react'
import Modal from '../ui/Modal'
import { CATEGORIES, DIFFICULTY_LEVELS, PRIORITY_LEVELS } from '../../constants'

/**
 * Mevcut bir beceriyi düzenleme modalı.
 * skill prop'u ile başlangıç değerleri doldurulur.
 */
export default function EditSkillModal({ isOpen, onClose, onSave, skill }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: 'frontend',
    difficulty: 'medium',
    priority: 'normal',
    deadline: '',
  })
  const [errors, setErrors] = useState({})

  // Modal her açıldığında formu skill verileriyle doldur
  useEffect(() => {
    if (skill) {
      setForm({
        title: skill.title || '',
        description: skill.description || '',
        category: skill.category || 'frontend',
        difficulty: skill.difficulty || 'medium',
        priority: skill.priority || 'normal',
        deadline: skill.deadline || '',
      })
      setErrors({})
    }
  }, [skill, isOpen])

  const validate = () => {
    const errs = {}
    if (!form.title.trim()) errs.title = 'Başlık zorunludur.'
    if (form.title.trim().length > 80) errs.title = 'Başlık 80 karakterden uzun olamaz.'
    return errs
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) {
      setErrors(errs)
      return
    }
    onSave(skill.id, {
      title: form.title.trim(),
      description: form.description.trim(),
      category: form.category,
      difficulty: form.difficulty,
      priority: form.priority,
      deadline: form.deadline,
    })
    onClose()
  }

  const handleClose = () => {
    setErrors({})
    onClose()
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="✏️ Beceriyi Düzenle">
      <form onSubmit={handleSubmit} className="space-y-5" noValidate>

        {/* Başlık */}
        <div>
          <label htmlFor="edit-title" className="label">
            Başlık <span className="text-rose-400">*</span>
          </label>
          <input
            id="edit-title"
            type="text"
            placeholder="örn: React Hooks öğren"
            className={`input-field ${errors.title ? 'border-rose-500/60 focus:border-rose-500' : ''}`}
            value={form.title}
            onChange={(e) => {
              setForm({ ...form, title: e.target.value })
              if (errors.title) setErrors({ ...errors, title: undefined })
            }}
            maxLength={80}
            autoFocus
          />
          {errors.title && (
            <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {errors.title}
            </p>
          )}
        </div>

        {/* Açıklama */}
        <div>
          <label htmlFor="edit-desc" className="label">
            Açıklama <span className="text-slate-600">(isteğe bağlı)</span>
          </label>
          <textarea
            id="edit-desc"
            placeholder="Bu beceri/hedef hakkında kısa bir not..."
            className="input-field resize-none"
            rows={3}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            maxLength={300}
          />
          <p className="text-right text-xs text-slate-600 mt-1">{form.description.length}/300</p>
        </div>

        {/* Kategori */}
        <div>
          <label className="label">Kategori</label>
          <div className="grid grid-cols-4 gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.value}
                type="button"
                onClick={() => setForm({ ...form, category: cat.value })}
                className={`flex flex-col items-center gap-1 p-2.5 rounded-xl border text-xs font-medium transition-all duration-200
                  ${form.category === cat.value
                    ? `${cat.color} border-current scale-105`
                    : 'bg-white/5 border-white/10 text-slate-500 hover:bg-white/10 hover:text-slate-300'
                  }`}
              >
                <span className="text-lg">{cat.icon}</span>
                <span className="leading-tight text-center">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Zorluk Seviyesi */}
        <div>
          <label className="label">Zorluk Seviyesi</label>
          <div className="flex gap-3">
            {DIFFICULTY_LEVELS.map((level) => (
              <button
                key={level.value}
                type="button"
                onClick={() => setForm({ ...form, difficulty: level.value })}
                className={`flex-1 py-2.5 px-3 rounded-xl border text-sm font-semibold transition-all duration-200
                  ${form.difficulty === level.value
                    ? `${level.color} border-current scale-105`
                    : 'bg-white/5 border-white/10 text-slate-500 hover:bg-white/10 hover:text-slate-300'
                  }`}
              >
                {level.label}
              </button>
            ))}
          </div>
        </div>

        {/* Öncelik seviyesi */}
        <div>
          <label className="label">Öncelik</label>
          <div className="grid grid-cols-2 gap-2">
            {PRIORITY_LEVELS.map((level) => (
              <button
                key={level.value}
                type="button"
                onClick={() => setForm({ ...form, priority: level.value })}
                className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-semibold transition-all duration-200
                  ${form.priority === level.value
                    ? `${level.color} border-current scale-105`
                    : 'bg-white/5 border-white/10 text-slate-500 hover:bg-white/10 hover:text-slate-300'
                  }`}
              >
                <span>{level.icon}</span>
                {level.label}
              </button>
            ))}
          </div>
        </div>

        {/* Son tarih */}
        <div>
          <label htmlFor="edit-deadline" className="label">Bitiş Tarihi</label>
          <input
            id="edit-deadline"
            type="date"
            value={form.deadline}
            onChange={(e) => setForm({ ...form, deadline: e.target.value })}
            className="input-field"
          />
        </div>

        {/* Butonlar */}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={handleClose}
            className="btn-secondary flex-1"
          >
            İptal
          </button>
          <button
            type="submit"
            className="btn-primary flex-1"
          >
            Kaydet
          </button>
        </div>
      </form>
    </Modal>
  )
}
