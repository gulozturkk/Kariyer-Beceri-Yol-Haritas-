import { useEffect, useRef } from 'react'

/**
 * Yeniden kullanılabilir modal wrapper bileşeni.
 */
export default function Modal({ isOpen, onClose, title, children }) {
  const overlayRef = useRef(null)

  // ESC tuşuyla kapat
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape' && isOpen) onClose()
    }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  }, [isOpen, onClose])

  // Scroll kilit
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in"
      onClick={(e) => {
        if (e.target === overlayRef.current) onClose()
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      {/* Arka plan bulanıklığı */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

      {/* Modal içeriği */}
      <div className="relative flex max-h-[calc(100dvh-2rem)] w-full max-w-lg flex-col overflow-hidden glass-card shadow-2xl shadow-black/50 animate-scale-in">
        {/* Başlık */}
        <div className="flex flex-shrink-0 items-center justify-between p-6 border-b border-white/10">
          <h2 id="modal-title" className="text-xl font-bold text-white">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors duration-200 text-slate-400 hover:text-white"
            aria-label="Kapat"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* İçerik */}
        <div className="min-h-0 overflow-y-auto p-6 scrollbar-thin">{children}</div>
      </div>
    </div>
  )
}
