/**
 * Dinamik ilerleme çubuğu bileşeni.
 * value: 0-100 arası tamamlanma yüzdesi
 */
export default function ProgressBar({ value = 0, showLabel = true, height = 'h-2' }) {
  const color =
    value >= 70
      ? 'bg-emerald-400'
      : value >= 30
      ? 'bg-amber-400'
      : 'bg-indigo-400'

  const glowColor =
    value >= 70
      ? 'shadow-emerald-400/40'
      : value >= 30
      ? 'shadow-amber-400/40'
      : 'shadow-indigo-400/40'

  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-xs text-slate-400">Tamamlanma</span>
          <span className={`text-xs font-bold ${value >= 70 ? 'text-emerald-400' : value >= 30 ? 'text-amber-400' : 'text-indigo-400'}`}>
            %{value}
          </span>
        </div>
      )}
      <div className={`w-full bg-white/10 rounded-full ${height} overflow-hidden`}>
        <div
          className={`${height} rounded-full ${color} shadow-sm ${glowColor} transition-all duration-700 ease-out`}
          style={{ width: `${value}%` }}
          role="progressbar"
          aria-valuenow={value}
          aria-valuemin={0}
          aria-valuemax={100}
        />
      </div>
    </div>
  )
}
