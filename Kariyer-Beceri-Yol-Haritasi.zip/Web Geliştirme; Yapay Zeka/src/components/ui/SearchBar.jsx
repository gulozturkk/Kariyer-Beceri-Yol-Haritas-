import { CATEGORIES } from '../../constants'

/**
 * Başlığa göre arama ve kategoriye göre filtre bileşeni.
 */
export default function SearchBar({ search, onSearchChange, activeCategory, onCategoryChange }) {
  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6 animate-fade-in">
      {/* Arama inputu */}
      <div className="relative flex-1">
        <svg
          className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          type="text"
          placeholder="Beceri ara..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="input-field pl-9 pr-9"
        />
        {search && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            aria-label="Aramayı temizle"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Kategori filtre dropdown */}
      <div className="relative">
        <select
          value={activeCategory}
          onChange={(e) => onCategoryChange(e.target.value)}
          className="input-field pr-9 appearance-none cursor-pointer min-w-[160px]"
        >
          <option value="">Tüm Kategoriler</option>
          {CATEGORIES.map((cat) => (
            <option key={cat.value} value={cat.value}>
              {cat.icon} {cat.label}
            </option>
          ))}
        </select>
        <svg
          className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </div>
  )
}
