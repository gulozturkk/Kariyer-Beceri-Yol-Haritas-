import { useMemo } from 'react'
import { CATEGORIES, COLUMNS, COLUMN_LABELS, COLUMN_COLORS } from '../../constants'

/**
 * İstatistik ve grafik sayfası.
 * recharts kurulu değilse SVG tabanlı basit grafikler gösterir.
 */
export default function StatsPage({ skills, onClose }) {
  // Kategori bazlı dağılım
  const categoryStats = useMemo(() => {
    return CATEGORIES.map((cat) => {
      const count = skills.filter((s) => s.category === cat.value).length
      return { ...cat, count }
    }).filter((c) => c.count > 0)
  }, [skills])

  // Sütun bazlı dağılım
  const columnStats = useMemo(() => {
    return Object.values(COLUMNS).map((col) => ({
      label: COLUMN_LABELS[col],
      count: skills.filter((s) => s.status === col).length,
      colors: COLUMN_COLORS[col],
    }))
  }, [skills])

  // Zorluk bazlı dağılım
  const difficultyStats = useMemo(() => {
    const map = { easy: { label: 'Kolay', color: 'bg-emerald-500', count: 0 },
                  medium: { label: 'Orta', color: 'bg-amber-500', count: 0 },
                  hard: { label: 'Zor', color: 'bg-rose-500', count: 0 } }
    skills.forEach((s) => { if (map[s.difficulty]) map[s.difficulty].count++ })
    return Object.values(map)
  }, [skills])

  const total = skills.length
  const done = skills.filter((s) => s.status === COLUMNS.DONE).length
  const completionRate = total > 0 ? Math.round((done / total) * 100) : 0

  // Son 7 günde eklenen
  const recentCount = useMemo(() => {
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    return skills.filter((s) => new Date(s.createdAt) > weekAgo).length
  }, [skills])

  // SVG Donut chart helper
  function DonutChart({ data, size = 140 }) {
    const radius = 50
    const circumference = 2 * Math.PI * radius
    const cx = size / 2
    const cy = size / 2

    let offset = 0
    const slices = data.map((d) => {
      const pct = total > 0 ? d.count / total : 0
      const dash = pct * circumference
      const gap = circumference - dash
      const slice = { ...d, dash, gap, offset }
      offset += dash
      return slice
    })

    const colors = ['#6366f1','#f59e0b','#10b981','#ec4899','#06b6d4','#8b5cf6','#14b8a6','#64748b']

    if (total === 0) {
      return (
        <div className="flex items-center justify-center" style={{ width: size, height: size }}>
          <p className="text-slate-600 text-xs text-center">Henüz veri yok</p>
        </div>
      )
    }

    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {slices.map((slice, i) => (
          <circle
            key={slice.label}
            cx={cx}
            cy={cy}
            r={radius}
            fill="none"
            stroke={colors[i % colors.length]}
            strokeWidth="24"
            strokeDasharray={`${slice.dash} ${slice.gap}`}
            strokeDashoffset={-slice.offset}
            transform={`rotate(-90 ${cx} ${cy})`}
            style={{ opacity: 0.85 }}
          />
        ))}
        <text x={cx} y={cy - 6} textAnchor="middle" className="fill-white" fontSize="22" fontWeight="bold" fill="white">
          {completionRate}%
        </text>
        <text x={cx} y={cy + 12} textAnchor="middle" fontSize="9" fill="#64748b">
          tamamlandı
        </text>
      </svg>
    )
  }

  // Yatay bar chart
  function HorizontalBar({ label, count, maxCount, colorClass, icon }) {
    const pct = maxCount > 0 ? (count / maxCount) * 100 : 0
    return (
      <div className="flex items-center gap-3">
        <div className="w-28 flex items-center gap-1.5 flex-shrink-0">
          {icon && <span className="text-sm">{icon}</span>}
          <span className="text-xs text-slate-400 truncate">{label}</span>
        </div>
        <div className="flex-1 h-2 bg-white/5 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${colorClass}`}
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="text-xs font-bold text-slate-300 w-6 text-right">{count}</span>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md overflow-y-auto">
      <div className="max-w-4xl mx-auto px-4 py-8">

        {/* Üst bar */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-violet-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/30">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">İstatistikler & Analiz</h2>
              <p className="text-xs text-slate-500">Tüm verilerinin özeti</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="btn-secondary flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
            Kapat
          </button>
        </div>

        {/* Özet kartlar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Toplam Beceri', value: total, icon: '🎯', color: 'text-indigo-400' },
            { label: 'Tamamlandı', value: done, icon: '✅', color: 'text-emerald-400' },
            { label: 'Bu Hafta Eklendi', value: recentCount, icon: '🆕', color: 'text-violet-400' },
            { label: 'Tamamlanma Oranı', value: `${completionRate}%`, icon: '📊', color: 'text-amber-400' },
          ].map((card) => (
            <div key={card.label} className="glass-card p-4 text-center">
              <div className="text-2xl mb-1">{card.icon}</div>
              <div className={`text-2xl font-black ${card.color}`}>{card.value}</div>
              <div className="text-xs text-slate-500 mt-0.5">{card.label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {/* Donut chart + Sütun dağılımı */}
          <div className="glass-card p-6">
            <h3 className="text-sm font-bold text-slate-300 mb-5 flex items-center gap-2">
              <span>📈</span> Genel Durum Dağılımı
            </h3>
            <div className="flex items-center gap-6">
              <DonutChart data={columnStats} size={140} />
              <div className="flex-1 space-y-3">
                {columnStats.map((col) => (
                  <div key={col.label} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${col.colors.dot}`} />
                      <span className="text-xs text-slate-400">{col.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-200">{col.count}</span>
                      <span className="text-xs text-slate-600">
                        ({total > 0 ? Math.round((col.count / total) * 100) : 0}%)
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Zorluk dağılımı */}
          <div className="glass-card p-6">
            <h3 className="text-sm font-bold text-slate-300 mb-5 flex items-center gap-2">
              <span>⚡</span> Zorluk Seviyesi Dağılımı
            </h3>
            <div className="space-y-4">
              {difficultyStats.map((d) => (
                <div key={d.label}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-slate-400">{d.label}</span>
                    <span className="text-slate-300 font-bold">{d.count} beceri</span>
                  </div>
                  <div className="h-2.5 bg-white/5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${d.color}`}
                      style={{ width: total > 0 ? `${(d.count / total) * 100}%` : '0%' }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Motivasyon mesajı */}
            <div className="mt-6 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
              <p className="text-xs text-indigo-300 text-center">
                {completionRate === 100
                  ? '🎉 Tebrikler! Tüm becerileri tamamladın!'
                  : completionRate >= 50
                  ? `🚀 Harika gidiyorsun! ${100 - completionRate}% daha var.`
                  : total === 0
                  ? '💡 İlk hedefini ekleyerek başla!'
                  : `💪 ${done} beceri tamamlandı, devam et!`}
              </p>
            </div>
          </div>

          {/* Kategori dağılımı — tam genişlik */}
          <div className="glass-card p-6 md:col-span-2">
            <h3 className="text-sm font-bold text-slate-300 mb-5 flex items-center gap-2">
              <span>🏷️</span> Kategori Dağılımı
            </h3>
            {categoryStats.length === 0 ? (
              <p className="text-slate-600 text-sm text-center py-4">Henüz beceri eklenmedi.</p>
            ) : (
              <div className="space-y-3">
                {categoryStats
                  .sort((a, b) => b.count - a.count)
                  .map((cat) => (
                    <HorizontalBar
                      key={cat.value}
                      label={cat.label}
                      count={cat.count}
                      maxCount={Math.max(...categoryStats.map((c) => c.count))}
                      colorClass="bg-indigo-500"
                      icon={cat.icon}
                    />
                  ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  )
}
